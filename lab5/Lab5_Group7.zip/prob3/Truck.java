package lab5.prob3;

final public class Truck implements Vehicle{

	@Override
	public void startEngine() {
		// TODO Auto-generated method stub
		System.out.println("Truck is starting");
	}
}
