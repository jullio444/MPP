package lab5.prob3;

final public class ElectricCar implements Vehicle{

	@Override
	public void startEngine() {
		// TODO Auto-generated method stub
		System.out.println("ElectricCar is starting");
	}

}
