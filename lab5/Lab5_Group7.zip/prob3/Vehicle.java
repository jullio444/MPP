package lab5.prob3;

public interface Vehicle {
	
	public void startEngine();
}
