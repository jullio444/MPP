package lab5.prob3;

final public class Bus implements Vehicle{

	@Override
	public void startEngine() {
		// TODO Auto-generated method stub
		System.out.println("Bus is starting");
	}

}
