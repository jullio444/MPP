package lab5.prob3;

final public class Car implements Vehicle {
	
	@Override
	public void startEngine() {
		// TODO Auto-generated method stub
		System.out.println("Car is starting");
	}

}
