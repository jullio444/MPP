package lab5.prob2;

public interface Figure {
	public double computeArea();
}
