package lab5.prob1;

public class FlyWithWings implements FLyBehavior{

	@Override
	public void fly() {
		System.out.println("  fly with wings");	
	}

}
