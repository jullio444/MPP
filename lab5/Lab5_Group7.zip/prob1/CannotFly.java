package lab5.prob1;

public class CannotFly implements FLyBehavior {

	@Override
	public void fly() {
		System.out.println("  cannot fly");
	}

}
